# VEX Push Back 2026 — Robot Code
> V5RC Season 2025–2026 | VEXcode C++ | Competition Template

---

## 📁 Project Structure

```
vex-pushback-2026/
├── src/
│   ├── main.cpp          ← Entry point + competition template
│   ├── autonomous.cpp    ← All three autonomous routines
│   ├── drivetrain.cpp    ← Drive base movement & PID
│   ├── intake.cpp        ← Block intake / outtake system
│   ├── arm.cpp           ← Lift arm with PID position control
│   ├── sensors.cpp       ← All sensor helpers & vision alignment
│   └── robot-config.cpp  ← Hardware port assignments
├── include/
│   ├── robot-config.h    ← Port map, constants, speed presets
│   ├── autonomous.h      ← Autonomous function declarations
│   ├── drivetrain.h      ← Drivetrain function declarations
│   ├── intake.h          ← Intake function declarations
│   ├── arm.h             ← Arm function declarations
│   └── sensors.h         ← Sensor function declarations
├── README.md             ← This file
└── STRATEGY.md           ← Scoring analysis & trade-offs
```

---

## ⚙️ Hardware Requirements

| System | Component | Port | Notes |
|--------|-----------|------|-------|
| Drive | Motor × 6 (blue cart.) | 1–6 | 3 left, 3 right |
| Intake | Motor × 2 (green cart.) | 7–8 | Reversed mount |
| Arm | Motor × 1 (green cart.) | 9 | Position-controlled |
| Inertial | V5 Inertial Sensor | 10 | Required for auto |
| Odometry | Rotation Sensor × 2 | 11–12 | Left + Right |
| Distance | V5 Distance Sensor | 13 | Front-facing |
| Vision | V5 Vision Sensor | 14 | Optional (improves align) |
| Optical | V5 Optical Sensor | 15 | Block detection |

> **Tip:** Change all port numbers in `src/robot-config.cpp` to match your physical wiring.

---

## 🚀 Installation

### Prerequisites
- **VEXcode Pro V5** (v2.x or later) — [download here](https://www.vex.com/vexcode)
- VEX V5 Brain + Controller connected via USB
- Git (optional, for cloning)

### Step 1 — Get the Code

**Option A — GitHub Clone (recommended)**
```bash
git clone https://github.com/YOUR_USERNAME/vex-pushback-2026.git
cd vex-pushback-2026
```

**Option B — Download ZIP**
1. Click **Code → Download ZIP** on the GitHub repository page
2. Extract the ZIP to a folder of your choice

### Step 2 — Open in VEXcode Pro

1. Launch **VEXcode Pro V5**
2. Go to **File → Open**
3. Navigate to the `vex-pushback-2026` folder
4. Select the folder (VEXcode will detect the project files)

> If VEXcode asks to create a project, choose **"C++ Project"** and then manually copy the `src/` and `include/` files in.

### Step 3 — Configure Your Robot

1. Open `src/robot-config.cpp`
2. Change port numbers to match **your robot's wiring**
3. Open `include/robot-config.h`
4. Set your autonomous routine:
   ```cpp
   constexpr int ROUTINE = 2;        // 0, 1, or 2
   constexpr bool IS_RED_ALLIANCE = true;  // true=Red, false=Blue
   ```

### Step 4 — Calibrate the Vision Sensor (Optional)

1. Connect Vision Sensor to port 14
2. Open **VEXcode → Tools → Vision Utility**
3. Teach signatures:
   - `SIG 1` = Red game block (bright red)
   - `SIG 2` = Blue game block (bright blue)
   - `SIG 3` = Goal structure (light gray/white)
4. Save to Brain

### Step 5 — Build & Download

1. Click **Build** (✓ icon) — fix any compile errors
2. Plug USB cable from Computer → V5 Brain
3. Click **Download** (↓ icon)
4. Disconnect USB and test

---

## 🎮 Controller Button Mappings

### Primary Driver (Controller 1)

| Input | Function |
|-------|----------|
| Left Stick Y | Forward / Backward (Arcade mode) |
| Left Stick X | Turn Left / Right (Arcade mode) |
| Left Stick | Left Drive (Tank mode) |
| Right Stick Y | Right Drive (Tank mode) |
| **R1** (hold) | Intake In — pull blocks toward robot |
| **R2** (hold) | Intake Out — eject blocks into goal |
| **L1** (hold) | Arm Up (manual) |
| **L2** (hold) | Arm Down (manual) |
| **D-Pad Up** | Arm → High Score Position (preset) |
| **D-Pad Down** | Arm → Stowed (preset) |
| **Button A** | Quick-Score Macro (raise, eject, stow) |
| **Button B** | Park Assist (raise arm to park height) |

> **Drive Mode:** Default is **ARCADE**. Change `DRIVE_MODE` in `main.cpp` to `DriveMode::TANK` if preferred.

---

## 🤖 Autonomous Paths

### Path 0 — Block Score Priority
- **Best for:** Matches where your alliance partner is weak in auto
- **Steps:** Score 4 blocks into the long goal → attempt park
- **Expected points:** Up to 28 pts (12 block + 6 zone + 10 bonus)
- **Autonomous Win Point:** ✅ Likely if opponent scores < 18 pts

### Path 1 — Park Focused  
- **Best for:** When scoring is unreliable or opponent auto is very strong
- **Steps:** Score 1 preloaded block → drive directly to park zone
- **Expected points:** 8 pts (3 block + 5 park)
- **Autonomous Win Point:** ❌ Unlikely

### Path 2 — Balanced *(DEFAULT)*
- **Best for:** Most competition situations
- **Steps:** Score 2 blocks into center goal (zone control) → park
- **Expected points:** Up to 27 pts (6 block + 6 zone + 5 park + 10 bonus)
- **Autonomous Win Point:** ✅ Possible if opponent scores < 12 pts

---

## 🔧 PID Tuning Guide

All PID constants are in the header files. Tune in this order:

1. **Drive PID** (`include/drivetrain.h → DrivePID::`)
   - Increase `kP_Drive` until the robot reaches target then oscillates slightly
   - Add `kD_Drive` to dampen oscillation
   - Add tiny `kI_Drive` only if there's steady-state error

2. **Turn PID** (`include/drivetrain.h → DrivePID::`)
   - Same process with `kP_Turn`, `kI_Turn`, `kD_Turn`

3. **Arm PID** (`include/arm.h → ArmPID::`)
   - Start `kP` low (0.2), increase until arm reaches target
   - Add `kD` to prevent overshoot past the goal position

---

## ⚠️ Limitations & Known Issues

- **Vision Sensor alignment** requires teaching signatures before each competition — lighting changes affect accuracy
- **Auto paths are encoder-based** — wheel slip on slick mats can accumulate error over longer distances
- **Arm PID runs in a background task** — if Brain CPU is loaded, PID frequency may drop
- **15-second auto is tight for Path 0** — if blocks aren't where expected, the robot may run out of time before parking

---

## 🔮 Future Improvements

- [ ] Add odometry (X-Y position tracking) for true path planning
- [ ] Implement block-color rejection (auto eject wrong-color blocks)
- [ ] Add auton selector GUI on Brain screen with touchscreen
- [ ] Add secondary driver (Controller 2) for arm-only control
- [ ] Tune PID constants with systematic testing

---

## 📋 Rules Compliance Notes

| Rule | Status | Note |
|------|--------|------|
| Robot size limits | ✅ | No code restrictions; measure robot physically |
| V5 Inertial Sensor | ✅ Legal | Official VEX V5 Smart Sensor |
| V5 Vision Sensor | ✅ Legal | Official VEX V5 Smart Sensor |
| V5 Distance Sensor | ✅ Legal | Official VEX V5 Smart Sensor |
| Competition template | ✅ Used | `competition Competition;` in main.cpp |
| Auto uses field control | ✅ | Callbacks registered via `Competition.autonomous()` |

> Always verify sensor legality against the **current V5RC Game Manual** before competition. Rules may be updated.
