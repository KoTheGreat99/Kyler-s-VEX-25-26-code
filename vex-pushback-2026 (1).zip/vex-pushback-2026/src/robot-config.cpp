// all the hardware gets set up here, change port numbers if u rewired stuff

#include "vex.h"
#include "robot-config.h"

using namespace vex;

// brain and both controllers
brain      Brain;
controller Controller1(primary);
controller Controller2(partner);

// left drive (reversed cuz theyre mounted backwards on the robot)
motor LeftFront(PORT1, gearSetting::ratio6_1, true);
motor LeftMid  (PORT2, gearSetting::ratio6_1, true);
motor LeftBack (PORT3, gearSetting::ratio6_1, true);

// right drive, normal direction
motor RightFront(PORT4, gearSetting::ratio6_1, false);
motor RightMid  (PORT5, gearSetting::ratio6_1, false);
motor RightBack (PORT6, gearSetting::ratio6_1, false);

// group em so we can tell both sides wat to do at once
motor_group LeftDrive (LeftFront,  LeftMid,  LeftBack);
motor_group RightDrive(RightFront, RightMid, RightBack);

// intake rollers - right one is reversed so both spin inward
motor IntakeLeft (PORT7, gearSetting::ratio18_1, false);
motor IntakeRight(PORT8, gearSetting::ratio18_1, true);

// arm motor, green cart for torque
motor ArmMotor(PORT9, gearSetting::ratio18_1, false);

// sensors
inertial InertialSensor(PORT10);  // gyro
rotation LeftEncoder   (PORT11);  // left wheel tracker
rotation RightEncoder  (PORT12);  // right wheel tracker
distance FrontDistance (PORT13);  // front rangefinder
vision   VisionSensor  (PORT14);  // camera
optical  BlockOptical  (PORT15);  // block color checker
