// AUTO TIME - 15 seconds to do as much as possible lol

#include "vex.h"
#include "robot-config.h"
#include "autonomous.h"
#include "drivetrain.h"
#include "intake.h"
#include "arm.h"
#include "sensors.h"

using namespace vex;

// score N blocks into a goal (0=long goal, 1=center goal)
void scoreBlocksInGoal(int goalType, int numBlocks) {
    for (int i = 0; i < numBlocks; i++) {
        armIntakePosition(); // lower arm to grab level

        bool got = intakeUntilBlock(1500);
        if (!got) {
            Brain.Screen.print("no block found, skippin"); // rip
            continue;
        }

        // lift to the right height for this goal type
        if (goalType == 0) armScoreHigh(); // long goal is tall
        else               armScoreLow();  // center goal shorter

        driveToGoal(5.0, Speed::DRIVE_CREEP, 2000); // creep up to goal

        intakeForMs(Speed::INTAKE_SPEED, 800, true); // yeet block in

        driveInches(-8.0, Speed::DRIVE_SLOW); // back up

        armStow(); // tuck arm before moving again
    }
}

// drive into the park zone and stop there (dw we'll make it)
void parkInZone(bool slowApproach) {
    if (slowApproach) {
        driveInches(18.0, Speed::DRIVE_CREEP, 2000); // creep in so we dont overshoot
    } else {
        driveInches(24.0, Speed::DRIVE_FAST, 2000);
    }
    stopDrive(brakeType::hold); // stay put, dont drift out
}

// show what score we're expecting on brain screen before we run
void printExpectedScore(int pathID) {
    Brain.Screen.clearScreen();
    Brain.Screen.setCursor(1, 1);
    switch (pathID) {
        case 0:
            Brain.Screen.print("Path 0: Block Grind Mode");
            Brain.Screen.newLine();
            Brain.Screen.print("Expected ~28pts, AWP likely");
            break;
        case 1:
            Brain.Screen.print("Path 1: Park n Chill");
            Brain.Screen.newLine();
            Brain.Screen.print("Expected ~8pts, no AWP");
            break;
        default:
            Brain.Screen.print("Path 2: Balanced (default)");
            Brain.Screen.newLine();
            Brain.Screen.print("Expected ~27pts, AWP possible");
            break;
    }
    wait(1000, msec);
}

// ── PATH 0 ── score as many blocks as possible, park if time allows
// start position: up against wall closest to the long goal
void autoBlockScorePriority() {
    // score preloaded block 1 into long goal
    armScoreHigh();
    driveToGoal(5.0, 50.0, 2000);
    intakeForMs(100.0, 600, true); // spit it in
    driveInches(-12.0, 70.0);

    // go grab block 2 from the field
    armIntakePosition();
    turnDegrees(-45.0, Speed::TURN_SPEED);
    driveInches(24.0, Speed::DRIVE_FAST);
    intakeUntilBlock(2000); // nom

    // back to goal and score it
    turnToHeading(0.0, Speed::TURN_SPEED);
    armScoreHigh();
    driveToGoal(5.0, 50.0, 2000);
    intakeForMs(100.0, 600, true);
    driveInches(-10.0, 60.0);

    // block 3 go go go
    armIntakePosition();
    turnDegrees(30.0, Speed::TURN_SPEED);
    driveInches(18.0, Speed::DRIVE_FAST);
    intakeUntilBlock(1500);
    turnToHeading(0.0, Speed::TURN_SPEED);
    armScoreHigh();
    driveToGoal(5.0, 50.0, 2000);
    intakeForMs(100.0, 600, true);
    driveInches(-8.0, 60.0);

    // block 4 - this is tight on time ngl
    armIntakePosition();
    turnDegrees(-20.0, Speed::TURN_SPEED);
    driveInches(14.0, Speed::DRIVE_FAST);
    intakeUntilBlock(1000);
    turnToHeading(0.0, Speed::TURN_SPEED);
    armScoreHigh();
    driveToGoal(5.0, 50.0, 1500);
    intakeForMs(100.0, 600, true);
    driveInches(-6.0, 60.0);

    // park if we have any time left
    armStow();
    turnDegrees(90.0, Speed::TURN_SPEED);
    driveInches(36.0, Speed::DRIVE_FAST, 1000);
    stopDrive(brakeType::hold);

    Brain.Screen.print("path 0 done!!");
}

// ── PATH 1 ── score one block then sprint to the park zone
// start position: near park zone
void autoParkFocused() {
    // score the preloaded block real quick
    armScoreLow();
    driveInches(24.0, 70.0);
    driveToGoal(6.0, 40.0, 2000);
    intakeForMs(100.0, 700, true); // click click scored
    driveInches(-14.0, 70.0);

    // now book it to the park zone
    armStow();
    turnDegrees(90.0, Speed::TURN_SPEED);
    driveInches(48.0, Speed::DRIVE_FAST);

    parkInZone(true); // creep in so we dont fly past

    Brain.Screen.print("path 1 done, we parked!!");
}

// ── PATH 2 ── score 2 blocks into center goal then park (the safe play)
// start position: center of alliance side
void autoBalanced() {
    // little nudge forward to clear the starting tile
    driveInches(10.0, 60.0);
    turnToHeading(0.0);
    armScoreLow(); // center goal is shorter

    // try to use vision to line up, fall back to encoders if it cant see anything
    {
        vision::object obj;
        if (visionFindLargest(SIG_GOAL, obj)) {
            visionAlignTo(SIG_GOAL, 1500); // oh nice it sees the goal
        }
        // if vision fails we just trust the encoders, its probably fine
    }

    driveToGoal(5.5, 45.0, 2500);
    intakeForMs(100.0, 700, true); // block 1 in!! lets gooo
    driveInches(-10.0, 60.0);

    // go scoop block 2
    armIntakePosition();
    turnDegrees(-30.0, Speed::TURN_SPEED);
    driveInches(20.0, Speed::DRIVE_FAST);
    bool gotBlock = intakeUntilBlock(1500);

    if (gotBlock) {
        // sick we got it, go score it
        turnToHeading(0.0, Speed::TURN_SPEED);
        armScoreLow();
        driveToGoal(5.5, 40.0, 2000);
        intakeForMs(100.0, 700, true); // oh man block 2 is in there
        driveInches(-10.0, 60.0);
    }

    // head to park zone
    armStow();
    turnDegrees(135.0, Speed::TURN_SPEED);
    driveInches(30.0, Speed::DRIVE_FAST);
    parkInZone(true);

    Brain.Screen.print("path 2 done!!");
}

// pick whichever path is selected and run it
void runSelectedAutonomous() {
    // zero everything out first so we start fresh
    resetHeading();
    resetEncoders();
    armResetEncoder();

    printExpectedScore(AutoSelect::ROUTINE);

    switch (AutoSelect::ROUTINE) {
        case 0: autoBlockScorePriority(); break;
        case 1: autoParkFocused();        break;
        case 2: autoBalanced();           break;
        default:
            Brain.Screen.print("bruh unknown routine id"); // how did u even get here
            break;
    }
}
