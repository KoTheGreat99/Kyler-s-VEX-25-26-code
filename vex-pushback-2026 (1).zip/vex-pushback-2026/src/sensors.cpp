// all the sensor reading n setup stuff

#include "vex.h"
#include "robot-config.h"
#include "sensors.h"
#include <cmath>

using namespace vex;

// boot up all sensors - robot has to be STILL during gyro calibration or it breaks
void initSensors() {
    Brain.Screen.clearScreen();
    Brain.Screen.print("calibrating gyro... dont touch!!");

    InertialSensor.calibrate();
    while (InertialSensor.isCalibrating()) {
        wait(20, msec); // just wait it out
    }

    Brain.Screen.clearScreen();
    Brain.Screen.print("sensors good to go");

    // turn on optical led for reliable block readings
    BlockOptical.setLight(ledState::on);
    BlockOptical.setLightPower(100, percent);

    LeftEncoder.resetPosition();
    RightEncoder.resetPosition();
}

// re-zero the gyro heading (call at the start of every auto run)
void calibrateInertial() {
    InertialSensor.calibrate();
    while (InertialSensor.isCalibrating()) wait(20, msec);
    InertialSensor.resetHeading();
}

// distance to whatever is in front of us (converts mm to inches)
double getFrontDistIn() {
    double distMM = FrontDistance.objectDistance(mm);
    if (distMM < 0 || distMM > 2000) return 999.0; // nothing there
    return distMM / 25.4;
}

// is something closer than X inches in front
bool isFrontObjectWithin(double distIn) {
    return getFrontDistIn() <= distIn;
}

// take a snapshot and find the biggest thing matching the signature
bool visionFindLargest(int sigID, vision::object &obj) {
    VisionSensor.takeSnapshot(sigID);
    if (VisionSensor.objectCount == 0) return false; // cant see anything rip
    obj = VisionSensor.largestObject;
    return obj.exists;
}

// how many pixels left or right the object is from dead center
int visionHorizontalOffset(const vision::object &obj) {
    constexpr int CENTER_X = 157; // middle of the 316px wide frame
    return static_cast<int>(obj.centerX) - CENTER_X;
}

// steer left/right until the target is centered in the camera view
bool visionAlignTo(int sigID, int timeout) {
    int startTime = Brain.Timer.time(msec);
    constexpr int   ALIGN_THRESHOLD = 15;   // pixels, close enuf
    constexpr double ALIGN_SPEED    = 20.0;

    while (Brain.Timer.time(msec) - startTime < timeout) {
        vision::object obj;
        if (!visionFindLargest(sigID, obj)) break; // lost it

        int offset = visionHorizontalOffset(obj);
        if (std::abs(offset) <= ALIGN_THRESHOLD) return true; // centered!!

        // nudge toward the target
        double turnPow = (offset > 0) ? ALIGN_SPEED : -ALIGN_SPEED;
        extern vex::motor_group LeftDrive, RightDrive;
        LeftDrive .spin(forward,  turnPow, percent);
        RightDrive.spin(forward, -turnPow, percent);
        wait(10, msec);
    }

    extern vex::motor_group LeftDrive, RightDrive;
    LeftDrive .stop(brakeType::brake);
    RightDrive.stop(brakeType::brake);
    return false; // couldnt align in time oh well
}

// is something close to the optical sensor rn
bool opticalDetectsObject() {
    return BlockOptical.isNearObject();
}

// what color is it (0-360 hue)
double opticalHue() {
    return BlockOptical.hue();
}

// red blocks have hue near 0/360 on the color wheel
bool isRedBlock() {
    double h = opticalHue();
    return (h <= 30.0 || h >= 330.0) && opticalDetectsObject();
}

// blue blocks are around 200-250 hue
bool isBlueBlock() {
    double h = opticalHue();
    return (h >= 200.0 && h <= 250.0) && opticalDetectsObject();
}

// slap all the sensor values on screen, good for debuging before a match
void printSensorDiagnostics() {
    Brain.Screen.clearScreen();
    Brain.Screen.setCursor(1, 1);
    Brain.Screen.print("Head: %.1f", InertialSensor.heading(degrees));
    Brain.Screen.newLine();
    Brain.Screen.print("Dist: %.1f in", getFrontDistIn());
    Brain.Screen.newLine();
    Brain.Screen.print("Hue:  %.0f",    opticalHue());
    Brain.Screen.newLine();
    Brain.Screen.print("Block: %s", BlockOptical.isNearObject() ? "YES" : "NO");
    Brain.Screen.newLine();
    Brain.Screen.print("L: %.0f  R: %.0f", LeftEncoder.position(degrees), RightEncoder.position(degrees));
}
