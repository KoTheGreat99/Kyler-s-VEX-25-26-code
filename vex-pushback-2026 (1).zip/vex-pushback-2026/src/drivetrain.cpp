// ts make the robot go where we want it to go

#include "vex.h"
#include "robot-config.h"
#include "drivetrain.h"
#include "sensors.h"
#include <cmath>

using namespace vex;

// inches → motor degrees conversion
static double inchesToDeg(double inches) {
    double rotations = inches / Field::WHEEL_CIRCUMFERENCE * Field::GEAR_RATIO;
    return rotations * 360.0;
}

// keep a number between two limits
static double clamp(double val, double minV, double maxV) {
    return std::max(minV, std::min(maxV, val));
}

// wrap heading so it stays 0-360
static double normalizeHeading(double h) {
    while (h <    0) h += 360;
    while (h >= 360) h -= 360;
    return h;
}

// zero out the wheel encoders
void resetEncoders() {
    LeftEncoder.resetPosition();
    RightEncoder.resetPosition();
}

// average both sides to get how far we traveled
void getDistanceTraveled() {
    double avgDeg = (LeftEncoder.position(degrees) + RightEncoder.position(degrees)) / 2.0;
    return (avgDeg / 360.0) * Field::WHEEL_CIRCUMFERENCE / Field::GEAR_RATIO;
}

// ask the gyro what direction we're facing
double getHeading() {
    return normalizeHeading(InertialSensor.heading(degrees));
}

// tell the gyro "this is zero now"
void resetHeading() {
    InertialSensor.resetHeading();
}

// drive straight using pid - this keeps us from drifting sideways
void driveInches(double inches, double speedPct, int timeout) {
    resetEncoders();

    double targetDeg = inchesToDeg(std::abs(inches));
    int    dir       = (inches >= 0) ? 1 : -1;
    double initHead  = getHeading(); // remember which way we started

    double error = 0, prevError = 0, integral = 0, derivative = 0;
    int startTime = Brain.Timer.time(msec);

    while (true) {
        if (Brain.Timer.time(msec) - startTime > timeout) break; // gave up lol

        // pid math to figure out how fast to go
        double traveledDeg = inchesToDeg(std::abs(getDistanceTraveled()));
        error      = targetDeg - traveledDeg;
        integral  += error;
        derivative = error - prevError;
        prevError  = error;

        double output = (DrivePID::kP_Drive * error)
                      + (DrivePID::kI_Drive * integral)
                      + (DrivePID::kD_Drive * derivative);
        output = clamp(output * dir, -speedPct, speedPct);

        // heading correction so we dont drift sideways like a goofball
        double headError = initHead - getHeading();
        if (headError >  180) headError -= 360;
        if (headError < -180) headError += 360;
        double headCorr = headError * 2.5;

        LeftDrive .spin(forward, output + headCorr, percent);
        RightDrive.spin(forward, output - headCorr, percent);

        if (std::abs(error) < inchesToDeg(DrivePID::DRIVE_THRESHOLD_IN)) break; // close enough!!
        wait(10, msec);
    }

    stopDrive();
}

// spin to a specific compass heading using pid
void turnToHeading(double targetDeg, double speedPct, int timeout) {
    targetDeg = normalizeHeading(targetDeg);
    double error = 0, prevError = 0, integral = 0, derivative = 0;
    int startTime = Brain.Timer.time(msec);

    while (true) {
        if (Brain.Timer.time(msec) - startTime > timeout) break;

        error = targetDeg - getHeading();
        // take the short way around the circle
        if (error >  180) error -= 360;
        if (error < -180) error += 360;

        integral  += error;
        derivative = error - prevError;
        prevError  = error;

        double output = (DrivePID::kP_Turn * error)
                      + (DrivePID::kI_Turn * integral)
                      + (DrivePID::kD_Turn * derivative);
        output = clamp(output, -speedPct, speedPct);

        // spin in place (left fwd, right back or vice versa)
        LeftDrive .spin(forward,  output, percent);
        RightDrive.spin(forward, -output, percent);

        if (std::abs(error) < DrivePID::TURN_THRESHOLD_DEG) break; // nailed it
        wait(10, msec);
    }

    stopDrive();
}

// turn relative to current heading (+ = clockwise)
void turnDegrees(double degrees, double speedPct, int timeout) {
    turnToHeading(normalizeHeading(getHeading() + degrees), speedPct, timeout);
}

// tank drive cant strafe lol, this does nothing
void strafeInches(double, double, int) {
    Brain.Screen.print("strafe not supported smh");
}

// stop all drive motors
void stopDrive(brakeType mode) {
    LeftDrive .stop(mode);
    RightDrive.stop(mode);
}

// one side slower than the other = curved path
void arcTurn(double leftPct, double rightPct, int ms) {
    LeftDrive .spin(forward, leftPct,  percent);
    RightDrive.spin(forward, rightPct, percent);
    wait(ms, msec);
    stopDrive();
}

// creep forward until the distance sensor says were close enough to the goal
void driveToGoal(double stopDistIn, double speedPct, int timeout) {
    int startTime = Brain.Timer.time(msec);
    while (Brain.Timer.time(msec) - startTime < timeout) {
        double dist = getFrontDistIn();
        if (dist <= stopDistIn) break; // we're there!!

        // slow down the closer we get
        double t   = clamp((dist - stopDistIn) / 24.0, 0.2, 1.0);
        double spd = speedPct * t;

        LeftDrive .spin(forward, spd, percent);
        RightDrive.spin(forward, spd, percent);
        wait(10, msec);
    }
    stopDrive();
}

// read joysticks and drive the robot, call this every loop
void teleopDrive(DriveMode mode) {
    if (mode == DriveMode::ARCADE) {
        // left stick up/down = go, left stick left/right = turn
        double throttle = Controller1.Axis3.position();
        double steer    = Controller1.Axis4.position();

        // deadband so tiny stick drift doesnt move the robot
        if (std::abs(throttle) < 5) throttle = 0;
        if (std::abs(steer)    < 5) steer    = 0;

        double left  = throttle + steer;
        double right = throttle - steer;

        // normalize if we somehow went over 100%
        double maxVal = std::max(std::abs(left), std::abs(right));
        if (maxVal > 100) { left /= maxVal/100.0; right /= maxVal/100.0; }

        LeftDrive .spin(forward, left,  percent);
        RightDrive.spin(forward, right, percent);

    } else {
        // tank mode - left stick = left side, right stick = right side
        double leftPower  = Controller1.Axis3.position();
        double rightPower = Controller1.Axis2.position();

        if (std::abs(leftPower)  < 5) leftPower  = 0;
        if (std::abs(rightPower) < 5) rightPower = 0;

        LeftDrive .spin(forward, leftPower,  percent);
        RightDrive.spin(forward, rightPower, percent);
    }
}
