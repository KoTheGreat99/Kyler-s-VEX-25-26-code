// arm control - lift goes up lift goes down lol

#include "vex.h"
#include "robot-config.h"
#include "arm.h"
#include <cmath>

using namespace vex;

// internal pid state
static double armTarget  = 0.0;
static bool   pidEnabled = false;
static double integral   = 0.0;
static double prevError  = 0.0;

// zero the arm encoder at wherever it is rn
void armResetEncoder() {
    ArmMotor.resetPosition();
    integral  = 0;
    prevError = 0;
}

// where is the arm right now (degrees)
double armGetPosition() {
    return ArmMotor.position(degrees);
}

// pid loop - runs in a background task so it keeps updating constantly
void armPIDUpdate() {
    if (!pidEnabled) return;

    double error  = armTarget - armGetPosition();
    integral     += error;
    // clamp integral so it doesnt go wild (anti-windup)
    integral = std::max(-ArmPID::MAX_INTEGRAL, std::min(ArmPID::MAX_INTEGRAL, integral));
    double derivative = error - prevError;
    prevError = error;

    double output = (ArmPID::kP * error)
                  + (ArmPID::kI * integral)
                  + (ArmPID::kD * derivative);
    output = std::max(-100.0, std::min(100.0, output));

    ArmMotor.spin(forward, output, percent);
}

// move arm to target angle and wait till its there (or 2 sec timeout)
void armMoveTo(double targetDeg, double speedPct, bool waitForDone) {
    armTarget  = targetDeg;
    pidEnabled = true;
    integral   = 0;
    prevError  = 0;

    if (!waitForDone) return; // caller handles the loop themselves

    int startTime = Brain.Timer.time(msec);
    while (Brain.Timer.time(msec) - startTime < 2000) {
        if (std::abs(targetDeg - armGetPosition()) < ArmPID::THRESHOLD_DEG) break; // close enuf
        armPIDUpdate();
        wait(10, msec);
    }
    armHold();
}

// lock the arm where it is so gravity doesnt pull it down
void armHold() {
    pidEnabled = false;
    ArmMotor.stop(brakeType::hold);
}

// arm preset shortcuts
void armStow()           { armMoveTo(ArmPos::STOWED);     }   // tuck it away
void armIntakePosition() { armMoveTo(ArmPos::INTAKE);     }   // ready to scoop
void armScoreLow()       { armMoveTo(ArmPos::SCORE_LOW);  }   // mid height
void armScoreHigh()      { armMoveTo(ArmPos::SCORE_HIGH); }   // all the way up babyyy
void armParkPosition()   { armMoveTo(ArmPos::PARK);       }   // lil lift for parking

// driver manually pushing l1/l2 to move arm
void armManual(double voltsPct) {
    pidEnabled = false; // turn off pid when driver takes over
    ArmMotor.spin(forward, voltsPct, percent);
}

// read l1 l2 and dpad then move arm accordingly
void teleopArm() {
    bool l1 = Controller1.ButtonL1.pressing();
    bool l2 = Controller1.ButtonL2.pressing();
    bool up = Controller1.ButtonUp.pressing();
    bool dn = Controller1.ButtonDown.pressing();

    if (l1) {
        armManual(Speed::ARM_SPEED);         // l1 = go up
    } else if (l2) {
        armManual(-Speed::ARM_SPEED * 0.7);  // l2 = come down (slower so it doesnt slam)
    } else if (up) {
        armScoreHigh();                       // dpad up = snap to score position
    } else if (dn) {
        armStow();                            // dpad down = put it away
    } else {
        // nothing pressed, just hold where we are
        if (!pidEnabled) ArmMotor.stop(brakeType::hold);
    }

    // keep pid running if a preset was called
    if (pidEnabled) armPIDUpdate();
}
