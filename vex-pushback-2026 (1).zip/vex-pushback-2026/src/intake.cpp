// intake - nom nom blocks go brrr

#include "vex.h"
#include "robot-config.h"
#include "intake.h"
#include "sensors.h"

using namespace vex;

// track what the intake is doing
static IntakeState currentState = IntakeState::OFF;

// set both rollers at once (right motor was flipped in robot-config so both spin inward)
static void setIntakeMotors(double speedPct) {
    IntakeLeft .spin(forward, speedPct, percent);
    IntakeRight.spin(forward, speedPct, percent);
}

// suck in a block
void intakeIn(double speedPct) {
    currentState = IntakeState::INTAKING;
    setIntakeMotors(speedPct);
}

// spit block into goal
void intakeOut(double speedPct) {
    currentState = IntakeState::OUTTAKING;
    setIntakeMotors(-speedPct); // negative = reverse = yeet
}

// stop the rollers
void intakeStop(brakeType mode) {
    currentState = IntakeState::OFF;
    IntakeLeft .stop(mode);
    IntakeRight.stop(mode);
}

// run intake for X ms then stop (handy in auto)
void intakeForMs(double speedPct, int ms, bool reverse) {
    if (reverse) intakeOut(speedPct);
    else         intakeIn(speedPct);
    wait(ms, msec);
    intakeStop();
}

// check if theres actually a block sitting in the intake rn
bool blockDetected() {
    BlockOptical.setLight(ledState::on); // turn led on for accurate readings
    return BlockOptical.isNearObject();
}

// is it our teams block color
bool correctColorBlock() {
    if (!blockDetected()) return false;
    if (AutoSelect::IS_RED_ALLIANCE) return isRedBlock();
    else                             return isBlueBlock();
}

// keep intaking until we grab something (or we give up after timeout)
bool intakeUntilBlock(int timeout) {
    intakeIn(Speed::INTAKE_SPEED);
    int startTime = Brain.Timer.time(msec);

    while (Brain.Timer.time(msec) - startTime < timeout) {
        if (blockDetected()) {
            // got one!! hold it so it doesnt slip out
            intakeStop(brakeType::hold);
            currentState = IntakeState::HOLDING;
            return true;
        }
        wait(10, msec);
    }

    intakeStop(); // nothing found, rip
    return false;
}

// driver presses r1 to intake, r2 to score, nothing = hold the block
void teleopIntake() {
    if (Controller1.ButtonR1.pressing()) {
        intakeIn(Speed::INTAKE_SPEED);
    } else if (Controller1.ButtonR2.pressing()) {
        intakeOut(Speed::INTAKE_SPEED);
    } else {
        // no button pressed - hold if we have a block, else coast
        if (currentState == IntakeState::HOLDING) {
            setIntakeMotors(15.0); // just enough power to not drop it
        } else {
            intakeStop(brakeType::coast);
            currentState = IntakeState::OFF;
        }
    }
}

// what mode is the intake in rn
IntakeState getIntakeState() {
    return currentState;
}
