// main file - this is where everything kicks off

#include "vex.h"
#include "robot-config.h"
#include "drivetrain.h"
#include "intake.h"
#include "arm.h"
#include "sensors.h"
#include "autonomous.h"

using namespace vex;

// competition object - the field controller talks to this
competition Competition;

// arcade or tank, change it here
constexpr DriveMode DRIVE_MODE = DriveMode::ARCADE;

// background task that keeps the arm pid running non-stop
int armPIDTask() {
    while (true) {
        armPIDUpdate();  // oh man lift is updating every 10ms
        wait(10, msec);
    }
    return 0;
}

// background task that shows live info on the brain screen
int dashboardTask() {
    while (true) {
        Brain.Screen.clearScreen();
        Brain.Screen.setCursor(1, 1);
        Brain.Screen.print("=== push back 2026 ===");
        Brain.Screen.newLine();
        Brain.Screen.print("arm: %.0f deg",  armGetPosition());
        Brain.Screen.newLine();
        Brain.Screen.print("head: %.1f",     getHeading());
        Brain.Screen.newLine();
        Brain.Screen.print("dist: %.1f in",  getFrontDistIn());
        Brain.Screen.newLine();
        Brain.Screen.print("block: %s",      blockDetected() ? "YES" : "NO ");
        Brain.Screen.newLine();
        Brain.Screen.print("auto: path %d",  AutoSelect::ROUTINE);
        wait(100, msec); // update 10x per second
    }
    return 0;
}

// runs once when u turn the robot on, sets everything up
void pre_auton() {
    Brain.Screen.print("setting up...");

    initSensors(); // calibrate gyro, takes ~2 sec, dont move robot

    armResetEncoder();      // zero arm wherever it starts
    armHold();              // hold arm in place
    intakeStop(brakeType::coast); // intake off

    Brain.Screen.clearScreen();
    Brain.Screen.print("ready!! path=%d %s",
        AutoSelect::ROUTINE,
        AutoSelect::IS_RED_ALLIANCE ? "RED" : "BLUE");
}

// 15 second auto period - driver input is blocked
void autonomous() {
    runSelectedAutonomous(); // let the robot cook

    // lock everything when auto ends
    stopDrive(brakeType::hold);
    armHold();
    intakeStop(brakeType::hold);
}

// 1:45 of driver control - u got the wheel now
void usercontrol() {
    // kick off background tasks
    task armTask (armPIDTask);
    task dispTask(dashboardTask);

    Controller1.rumble("."); // buzz to tell driver control started

    while (true) {
        teleopDrive(DRIVE_MODE);  // ts make the robot go

        teleopIntake();           // r1 to grab, r2 to score

        teleopArm();              // l1/l2 to move arm, dpad for presets

        // clickkk a to do a quick score all at once
        if (Controller1.ButtonA.pressing()) {
            armScoreHigh();
            intakeForMs(100.0, 600, true);
            armStow();
        }

        // clickk b to raise arm to park height
        if (Controller1.ButtonB.pressing()) {
            armParkPosition();
        }

        // buzz controller when we pick up a block (nice little feedback)
        static bool wasDetected = false;
        bool nowDetected = blockDetected();
        if (nowDetected && !wasDetected) {
            Controller1.rumble("."); // got one!!
        }
        wasDetected = nowDetected;

        wait(20, msec); // ~50Hz loop, smoooth
    }
}

// entry point - dont put code down here lol
int main() {
    Competition.autonomous(autonomous);
    Competition.drivercontrol(usercontrol);

    pre_auton();

    // keep the program alive (competition framework takes it from here)
    while (true) {
        wait(100, msec);
    }
}
