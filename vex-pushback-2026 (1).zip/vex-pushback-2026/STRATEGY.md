# VEX Push Back 2026 — Strategy Document

---

## 1. Game Overview

**Field:** 12′×12′ square  
**Game Objects:** 88 blocks (44 red + 44 blue)  
**Goals:** 4 total (2 long goals, 2 center goals per alliance side)  
**Park Zones:** 2 (one per alliance)  
**Periods:** Autonomous (15 s) + Driver Control (1:45 = 105 s)

---

## 2. Scoring Rules Summary

| Scoring Event | Points |
|---------------|--------|
| Block scored in any goal | 3 pts each |
| Zone control of a goal | 6 pts per goal |
| Autonomous Bonus | 10 pts (if auto score > opponent auto score) |
| Autonomous Win Point (RP) | +1 ranking point |
| Robot parked in Park Zone | 5 pts per robot |

**Zone Control:** Your alliance controls a goal's zone if you have more blocks in it than the opponent alliance. Only the alliance with majority blocks gets the 6-point zone bonus.

---

## 3. Autonomous Scoring Analysis

### Path 0 — Block Score Priority

**Assumptions:**  
- 4 blocks scored in long goal (near starting position)  
- Zone control of long goal achieved (4 vs 0 opponent blocks)  
- Park attempted if time permits  

| Component | Pts |
|-----------|-----|
| 4 blocks × 3 | 12 |
| Long goal zone control | 6 |
| Autonomous Bonus | 10 |
| **Total (best case)** | **28** |

**Trade-offs:**  
- Most aggressive scoring strategy  
- Requires reliable intake; if blocks are missed, score drops sharply  
- Park is deprioritized — lose 5 pts vs paths 1/2  
- AWP earned if opponent auto scores ≤ 18 pts  

---

### Path 1 — Park Focused

**Assumptions:**  
- 1 preloaded block scored into nearest goal  
- Robot drives to Park Zone and stops  

| Component | Pts |
|-----------|-----|
| 1 block × 3 | 3 |
| Park | 5 |
| Autonomous Bonus | 0 |
| **Total** | **8** |

**Trade-offs:**  
- Very reliable — minimal movement, low failure risk  
- Sacrifices 20 pts of potential vs Path 0  
- Best used when opponent auto is very strong (preventing AWP anyway) or robot is unreliable  
- AWP not achievable in most cases  

---

### Path 2 — Balanced *(DEFAULT)*

**Assumptions:**  
- 2 blocks scored into center goal  
- Zone control of center goal achieved (2 vs 0)  
- Robot parks successfully  
- Autonomous Bonus awarded (if opponent scores < 12 pts)  

| Component | Pts |
|-----------|-----|
| 2 blocks × 3 | 6 |
| Center goal zone control | 6 |
| Park | 5 |
| Autonomous Bonus | 10 |
| **Total (best case)** | **27** |

**Trade-offs:**  
- Reliable and competitive  
- Zone control via center goal is more accessible than long goal  
- Vision sensor alignment increases center goal scoring reliability  
- AWP possible if opponent auto scores < 12 pts  

---

## 4. Autonomous Win Point (AWP) Strategy

The AWP is the most valuable outcome per ranking point. Prioritize it when:

1. **Your partner's auto is strong** — combined alliance auto score likely > opponent
2. **Opponent auto is weak** — safe to go all-in on scoring
3. **You are early in qualifications** — ranking points matter most early

**AWP Decision Tree:**
```
Opponent auto expected score:
  < 10 pts  → Use Path 2 (Balanced) — 27 pts likely earns bonus
  10-18 pts → Use Path 0 (Block Priority) — 28 pts needed
  > 18 pts  → Use Path 1 (Park) — save robot for driver control
```

---

## 5. Driver Control Scoring Strategy

**Goals per minute rate:**  
Experienced driver can score ~8–12 blocks per minute = **24–36 pts/min**  
In 1:45 driver control: potential of **42–63 pts** from blocks alone  

### Recommended Priority Order (Driver Control)

1. **Long goals first** — more physical space for blocks, easier to maintain zone control
2. **Defense second** — if opponent controls a goal you can't reach, prioritize a different goal
3. **Park at 0:10 remaining** — park is guaranteed 5 pts vs risky last-second scoring
4. **Zone control watch** — monitor opponent's block count; if they approach your total, score more

### Efficient Scoring Loop

```
Intake block → Drive to goal → Outtake → Drive back → Repeat
```
Each loop should take ~6–8 seconds = **~8–10 loops in 1:45**  
Target: at least 16 blocks scored (48 pts from blocks alone)

---

## 6. Field Zone Map

```
┌─────────────────────────────────────────┐
│  BLUE                            RED    │
│  Park Zone                    Park Zone │
│  ┌──────┐                    ┌──────┐   │
│  │ PARK │                    │ PARK │   │
│  └──────┘                    └──────┘   │
│                                         │
│  ┌──────────────────────────────────┐   │
│  │         CENTER GOALS (×2)        │   │
│  └──────────────────────────────────┘   │
│                                         │
│  ┌──────────────────────────────────┐   │
│  │          LONG GOALS (×2)         │   │
│  └──────────────────────────────────┘   │
│                                         │
│  BLUE start                  RED start  │
└─────────────────────────────────────────┘
```

---

## 7. Alliance Selection Considerations

When choosing an alliance partner, prioritize partners who:

- Have reliable autonomous (to guarantee AWP together)
- Specialize in a **different goal** so you don't compete for the same scoring zone
- Have a fast driver-control cycle for block scoring
- Have a robot that can park (stacking park points = +10 pts combined)

---

## 8. Expected Match Score Estimate

| Phase | Your Robot | Estimate |
|-------|-----------|---------|
| Autonomous | Path 2 (Balanced) | 17–27 pts |
| Driver Control | 10 blocks scored | 30 pts |
| Park | End of match | 5 pts |
| **Total (your robot)** | | **52–62 pts** |
| **Alliance Total** | With strong partner | **90–120 pts** |

---

## 9. PID Constants Justification

### Drive Straight PID
- `kP = 0.35` — Moderate gain; avoids oscillation on smooth tiles
- `kI = 0.001` — Tiny integral to handle minor friction differences
- `kD = 0.08` — Dampens overshoot on longer runs

### Turn PID
- `kP = 0.55` — Higher P needed for heavier inertia of turn-in-place
- `kI = 0.002` — Small integral for final degree accuracy
- `kD = 0.12` — Prevents spin-past on sharp turns

### Arm PID
- `kP = 0.8` — Fast response needed for quick scoring cycles
- `kI = 0.005` — Counteracts gravity-induced sag at high positions
- `kD = 0.15` — Prevents bounce at position target

> All PID values are starting points. Physical tuning on your specific robot is **required** before competition.

---

## 10. Known Risks & Mitigations

| Risk | Likelihood | Mitigation |
|------|-----------|------------|
| Block not in expected field location | Medium | Intake timeout prevents infinite search |
| Wheel slip causes position error | Medium | Inertial heading correction in drive PID |
| Vision sensor confused by field lighting | Low | Falls back to encoder-only path |
| Arm PID saturates against hard stop | Low | Encoder limits + 2-second timeout |
| Robot tips during sharp turns | Low | Reduce `TURN_SPEED` constant |
