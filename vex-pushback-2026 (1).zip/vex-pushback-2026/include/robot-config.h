#pragma once
// all the robot stuff lives here lol

#include "vex.h"

// brain + controllers, pretty obv
extern vex::brain      Brain;
extern vex::controller Controller1;
extern vex::controller Controller2;

// left motors (reversed cuz theyre flipped on the robot)
extern vex::motor LeftFront;
extern vex::motor LeftMid;
extern vex::motor LeftBack;

// right motors, normal direction
extern vex::motor RightFront;
extern vex::motor RightMid;
extern vex::motor RightBack;

// groups so we dont have to yell at all 3 motors individually lmao
extern vex::motor_group LeftDrive;
extern vex::motor_group RightDrive;

// rollers that suck in blocks
extern vex::motor IntakeLeft;
extern vex::motor IntakeRight;

// the arm thingy that picks stuff up
extern vex::motor ArmMotor;

// gyro basically, keeps us from spinning out lol
extern vex::inertial InertialSensor;

// track how far wheels actually moved
extern vex::rotation LeftEncoder;
extern vex::rotation RightEncoder;

// sonar lookin thing up front
extern vex::distance FrontDistance;

// camera for spotting blocks n goals
extern vex::vision VisionSensor;

// tiny sensor that checks if a block is there
extern vex::optical BlockOptical;

// field measurements, dont mess with these
namespace Field {
    constexpr double TILE_IN             = 24.0;
    constexpr double HALF_FIELD          = 72.0;
    constexpr double WHEEL_DIAMETER_IN   = 3.25;
    constexpr double WHEEL_CIRCUMFERENCE = WHEEL_DIAMETER_IN * M_PI;
    constexpr double GEAR_RATIO          = 1.0;
    constexpr double TRACK_WIDTH_IN      = 12.5;
    constexpr double DRIVE_MOTOR_RPM     = 600.0;
}

// speed settings, crank em up if ur feeling brave
namespace Speed {
    constexpr double DRIVE_FAST   = 100.0;
    constexpr double DRIVE_SLOW   = 40.0;
    constexpr double DRIVE_CREEP  = 20.0;  // creeping lol
    constexpr double TURN_SPEED   = 60.0;
    constexpr double INTAKE_SPEED = 100.0;
    constexpr double ARM_SPEED    = 70.0;
}

// arm positions in degrees (0 = tucked down, 150 = fully up)
namespace ArmPos {
    constexpr double STOWED    =   0.0;   // arm sleeping
    constexpr double INTAKE    =  15.0;   // ready to grab
    constexpr double SCORE_LOW =  80.0;
    constexpr double SCORE_HIGH= 150.0;   // all the way babyyy
    constexpr double PARK      =  30.0;
}

// CHANGE THESE BEFORE EVERY MATCH seriously dont forget
namespace AutoSelect {
    constexpr int  ROUTINE         = 2;     // 0=go hard, 1=park only, 2=balanced
    constexpr bool IS_RED_ALLIANCE = true;  // red=true, blue=false
}

// points u get for doing stuff (from the game manual)
namespace Score {
    constexpr int BLOCK_IN_GOAL     = 3;
    constexpr int ZONE_CONTROL      = 6;
    constexpr int AUTONOMOUS_BONUS  = 10;
    constexpr int AUTONOMOUS_WIN_PT = 1;
    constexpr int PARK_POINTS       = 5;
}
