#pragma once
// intake stuff - sucking in blocks n spitting em out

#include "vex.h"

// what the intake is doing rn
enum class IntakeState {
    OFF,
    INTAKING,   // nom nom blocks
    OUTTAKING,  // yeet blocks into goal
    HOLDING     // got a block, just holding on
};

// spin the rollers to grab blocks
void intakeIn(double speedPct = 100.0);

// reverse to shoot blocks into the goal
void intakeOut(double speedPct = 80.0);

// stop the intake
void intakeStop(vex::brakeType mode = vex::brakeType::hold);

// run for a set time then stop (good for auto)
void intakeForMs(double speedPct, int ms, bool reverse = false);

// is there a block in there rn
bool blockDetected();

// is it OUR teams color block
bool correctColorBlock();

// keep intaking until we get a block or give up
bool intakeUntilBlock(int timeout = 2000);

// driver presses r1/r2 to control intake
void teleopIntake();

// whats the intake doing rn
IntakeState getIntakeState();
