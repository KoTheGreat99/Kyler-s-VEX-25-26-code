#pragma once
// auto paths!! this is where the magic happens during the 15 sec auto period

#include "vex.h"

// path 0 - go hard, score as many blocks as possible
void autoBlockScorePriority();

// path 1 - score one block then book it to the park zone
void autoParkFocused();

// path 2 - score two blocks + park, the safe middle ground (default)
void autoBalanced();

// helper to score N blocks into a specific goal (0=long, 1=center)
void scoreBlocksInGoal(int goalType, int numBlocks = 1);

// drive into the park zone and stop there
void parkInZone(bool slowApproach = true);

// print what score we're expecting on the brain screen
void printExpectedScore(int pathID);

// picks whichever path AutoSelect::ROUTINE is set to and runs it
void runSelectedAutonomous();
