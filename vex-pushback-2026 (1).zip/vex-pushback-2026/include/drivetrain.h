#pragma once
// drivetrain stuff - making the robot go vroom

#include "vex.h"

// tank or arcade, ur choice
enum class DriveMode { TANK, ARCADE };

// go forward or backward a certain number of inches
void driveInches(double inches, double speedPct = 80.0, int timeout = 3000);

// spin to a heading using the gyro (0-360 degrees)
void turnToHeading(double targetDeg, double speedPct = 60.0, int timeout = 2000);

// turn by however many degrees from where u are rn
void turnDegrees(double degrees, double speedPct = 60.0, int timeout = 2000);

// sideways movement - doesnt work on tank drive so basically useless lol
void strafeInches(double inches, double speedPct = 60.0, int timeout = 2000);

// stop everything
void stopDrive(vex::brakeType mode = vex::brakeType::brake);

// one side faster than the other = arc turn
void arcTurn(double leftPct, double rightPct, int ms);

// creep up to a goal using the distance sensor
void driveToGoal(double stopDistIn = 6.0, double speedPct = 40.0, int timeout = 3000);

// reset encoders back to zero
void resetEncoders();

// how far we've gone since last reset
double getDistanceTraveled();

// current heading in degrees
double getHeading();

// zero out the heading
void resetHeading();

// read the joysticks and drive (call this every loop in teleop)
void teleopDrive(DriveMode mode = DriveMode::ARCADE);

// pid values, tune these if the robot is being weird
namespace DrivePID {
    constexpr double kP_Drive = 0.35;
    constexpr double kI_Drive = 0.001;
    constexpr double kD_Drive = 0.08;

    constexpr double kP_Turn  = 0.55;
    constexpr double kI_Turn  = 0.002;
    constexpr double kD_Turn  = 0.12;

    // close enough = good enough
    constexpr double DRIVE_THRESHOLD_IN = 0.5;
    constexpr double TURN_THRESHOLD_DEG = 1.5;
}
