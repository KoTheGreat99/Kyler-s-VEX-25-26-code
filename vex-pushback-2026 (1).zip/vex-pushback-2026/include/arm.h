#pragma once
// arm stuff - lifts blocks up so we can score them

#include "vex.h"

// move arm to a specific angle (degrees)
void armMoveTo(double targetDeg, double speedPct = 70.0, bool wait = true);

// shortcuts to common positions
void armStow();           // put it away
void armIntakePosition(); // low enugh to scoop
void armScoreLow();       // mid height for short goals
void armScoreHigh();      // all the way up
void armParkPosition();   // just a lil raised for parking

// manual control (driver pushing l1/l2)
void armManual(double voltsPct);

// stop arm and hold where it is
void armHold();

// where is the arm rn
double armGetPosition();

// zero the arm encoder at current spot
void armResetEncoder();

// the actual pid math, runs in a loop task
void armPIDUpdate();

// driver controls the arm with l1 l2 and dpad
void teleopArm();

// pid numbers for the arm, tweak if its bouncing or slow
namespace ArmPID {
    constexpr double kP = 0.8;
    constexpr double kI = 0.005;
    constexpr double kD = 0.15;
    constexpr double THRESHOLD_DEG = 3.0;  // close enough
    constexpr double MAX_INTEGRAL  = 50.0; // dont let i term go crazy
}
