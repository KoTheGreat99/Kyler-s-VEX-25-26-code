#pragma once
// all the sensor helpers live here

#include "vex.h"

// vision sig ids - gotta teach these in the vision utility app
constexpr int SIG_RED_BLOCK  = 1;
constexpr int SIG_BLUE_BLOCK = 2;
constexpr int SIG_GOAL       = 3;

// boot up all sensors, gyro takes like 2 sec to calibrate
void initSensors();

// re-zero the gyro (do this at the start of every auto)
void calibrateInertial();

// how far away is the thing in front of us (inches)
double getFrontDistIn();

// is something closer than X inches
bool isFrontObjectWithin(double distIn);

// look for a vision signature, returns true if found
bool visionFindLargest(int sigID, vex::vision::object &obj);

// how far off-center is the vision object (pixels)
int visionHorizontalOffset(const vex::vision::object &obj);

// steer until the target is centered in the camera
bool visionAlignTo(int sigID, int timeout = 2000);

// is the optical sensor seeing smthing close
bool opticalDetectsObject();

// color hue from the optical sensor (0-360)
double opticalHue();

// is it a red block
bool isRedBlock();

// is it a blue block
bool isBlueBlock();

// dump all sensor values to brain screen for debuging
void printSensorDiagnostics();
